package ObserverMode;

 interface DisplayElement {
    void display();
}
