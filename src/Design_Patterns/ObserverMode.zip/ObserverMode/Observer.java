package ObserverMode;

 interface Observer {
    void update(float temp,float humidity,float pressure);
}
